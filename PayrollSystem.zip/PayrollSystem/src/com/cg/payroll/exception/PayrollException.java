package com.cg.payroll.exception;

public class PayrollException  extends Exception{

}
