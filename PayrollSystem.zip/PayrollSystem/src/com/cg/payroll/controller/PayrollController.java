package com.cg.payroll.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Employee;
import com.cg.payroll.service.PayrollService;

@Controller
public class PayrollController {
	@Autowired
	 private PayrollService payrollService;
	
	@RequestMapping(value="/employees", method = RequestMethod.GET)
	 public ModelAndView listEmployees() throws SQLException {
	  Map<String, Object> model = new HashMap<String ,Object>();
	  model.put("employees",  prepareListofBean(payrollService.getAllEmployee()));
	  return new ModelAndView("employeesList", model);
	 }
	
		private List<Employee> prepareListofBean(List<Employee> employee){
			  List<Employee> beans = null;
			  if(employee != null && !employee.isEmpty()){
			   beans = new ArrayList<Employee>();
			   Employee bean = null;
			   for(Employee employee1 : employee){
			    bean = new Employee();
			    bean.setFirstName(employee1.getFirstName());
			    bean.setLastName(employee1.getFirstName());
			    bean.setEmailId(employee1.getEmailId());
			    bean.setEmpId(employee1.getEmpId());
			    bean.setBankDetails(employee1.getBankDetails());
			    bean.setMobileNo(employee1.getMobileNo());
			    bean.setPanCard(employee1.getPanCard());
			    bean.setSalary(employee1.getSalary());
			    bean.setYearlyInvestmentUnderPOC(employee1.getYearlyInvestmentUnderPOC());
			    beans.add(bean);
			   }
			  }
			  return beans;
			 }
			 
	}


