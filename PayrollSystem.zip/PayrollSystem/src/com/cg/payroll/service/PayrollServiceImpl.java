package com.cg.payroll.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.payroll.beans.Employee;
import com.cg.payroll.dao.IPayrollDAO;

public class PayrollServiceImpl  implements PayrollService
{
	@Autowired
	private IPayrollDAO iparollDao;

	public int insertEmployee(Employee employee)  throws SQLException 
	{
		
		iparollDao.insertEmployee(employee);
		return 0;
	}

	public boolean updateEmployee(Employee employee)  throws SQLException 
	{
		iparollDao.updateEmployee(employee);
		
		return false;
	}

	public boolean deleteEmployee(Employee employee)  throws SQLException 
	{
		
		return iparollDao.deleteEmployee(employee);
	}

	public Employee getEmployee(int employeeId)  throws SQLException 
	{
		
		return iparollDao.getEmployee(employeeId);
	}

	public List<Employee> getAllEmployee()  throws SQLException 
	{
		
		return iparollDao.getAllEmployee();
	}

}
