package com.cg.payroll.beans;

public class Salary {
	private int basicSalary;
	private int hra;
	private int ta;
	private int td;
	private int da;
	private int companyPf;
	private int employeePf;
	private int grossSalary;
	private int monthlyTax;
	private int netSalary;
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	
	
	@Override
	public String toString() {
		return "salary [basicSalary=" + basicSalary + ", companyPf="
				+ companyPf + ", da=" + da + ", employeePf=" + employeePf
				+ ", grossSalary=" + grossSalary + ", hra=" + hra
				+ ", monthlyTax=" + monthlyTax + ", netSalary=" + netSalary
				+ ", ta=" + ta + ", td=" + td + "]";
	}


	/**
	 * @return the basicSalary
	 */
	public int getBasicSalary() {
		return basicSalary;
	}


	/**
	 * @param basicSalary the basicSalary to set
	 */
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}


	/**
	 * @return the hra
	 */
	public int getHra() {
		return hra;
	}


	/**
	 * @param hra the hra to set
	 */
	public void setHra(int hra) {
		this.hra = hra;
	}


	/**
	 * @return the ta
	 */
	public int getTa() {
		return ta;
	}


	/**
	 * @param ta the ta to set
	 */
	public void setTa(int ta) {
		this.ta = ta;
	}


	/**
	 * @return the td
	 */
	public int getTd() {
		return td;
	}


	/**
	 * @param td the td to set
	 */
	public void setTd(int td) {
		this.td = td;
	}


	/**
	 * @return the da
	 */
	public int getDa() {
		return da;
	}


	/**
	 * @param da the da to set
	 */
	public void setDa(int da) {
		this.da = da;
	}


	/**
	 * @return the companyPf
	 */
	public int getCompanyPf() {
		return companyPf;
	}


	/**
	 * @param companyPf the companyPf to set
	 */
	public void setCompanyPf(int companyPf) {
		this.companyPf = companyPf;
	}


	/**
	 * @return the employeePf
	 */
	public int getEmployeePf() {
		return employeePf;
	}


	/**
	 * @param employeePf the employeePf to set
	 */
	public void setEmployeePf(int employeePf) {
		this.employeePf = employeePf;
	}


	/**
	 * @return the grossSalary
	 */
	public int getGrossSalary() {
		return grossSalary;
	}


	/**
	 * @param grossSalary the grossSalary to set
	 */
	public void setGrossSalary(int grossSalary) {
		this.grossSalary = grossSalary;
	}


	/**
	 * @return the monthlyTax
	 */
	public int getMonthlyTax() {
		return monthlyTax;
	}


	/**
	 * @param monthlyTax the monthlyTax to set
	 */
	public void setMonthlyTax(int monthlyTax) {
		this.monthlyTax = monthlyTax;
	}


	/**
	 * @return the netSalary
	 */
	public int getNetSalary() {
		return netSalary;
	}


	/**
	 * @param netSalary the netSalary to set
	 */
	public void setNetSalary(int netSalary) {
		this.netSalary = netSalary;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + basicSalary;
		result = prime * result + companyPf;
		result = prime * result + da;
		result = prime * result + employeePf;
		result = prime * result + grossSalary;
		result = prime * result + hra;
		result = prime * result + monthlyTax;
		result = prime * result + netSalary;
		result = prime * result + ta;
		result = prime * result + td;
		return result;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Salary other = (Salary) obj;
		if (basicSalary != other.basicSalary)
			return false;
		if (companyPf != other.companyPf)
			return false;
		if (da != other.da)
			return false;
		if (employeePf != other.employeePf)
			return false;
		if (grossSalary != other.grossSalary)
			return false;
		if (hra != other.hra)
			return false;
		if (monthlyTax != other.monthlyTax)
			return false;
		if (netSalary != other.netSalary)
			return false;
		if (ta != other.ta)
			return false;
		if (td != other.td)
			return false;
		return true;
	}
	
	
	
	

}
