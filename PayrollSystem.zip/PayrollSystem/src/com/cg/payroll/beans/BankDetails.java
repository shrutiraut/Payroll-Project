package com.cg.payroll.beans;

public class BankDetails {
	private int accountNo;
	private String bankName;
	private String bankIFSCCode;
	/**
	 * @return the accountNo
	 */
	public int getAccountNo() {
		return accountNo;
	}
	/**
	 * @param accountNo the accountNo to set
	 */
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}
	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	/**
	 * @return the bankIFSCCode
	 */
	public String getBankIFSCCode() {
		return bankIFSCCode;
	}
	/**
	 * @param bankIFSCCode the bankIFSCCode to set
	 */
	public void setBankIFSCCode(String bankIFSCCode) {
		this.bankIFSCCode = bankIFSCCode;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BankDetails [accountNo=" + accountNo + ", bankName=" + bankName
				+ ", bankIFSCCode=" + bankIFSCCode + "]";
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNo;
		result = prime * result
				+ ((bankIFSCCode == null) ? 0 : bankIFSCCode.hashCode());
		result = prime * result
				+ ((bankName == null) ? 0 : bankName.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankDetails other = (BankDetails) obj;
		if (accountNo != other.accountNo)
			return false;
		if (bankIFSCCode == null) {
			if (other.bankIFSCCode != null)
				return false;
		} else if (!bankIFSCCode.equals(other.bankIFSCCode))
			return false;
		if (bankName == null) {
			if (other.bankName != null)
				return false;
		} else if (!bankName.equals(other.bankName))
			return false;
		return true;
	}
	

}
