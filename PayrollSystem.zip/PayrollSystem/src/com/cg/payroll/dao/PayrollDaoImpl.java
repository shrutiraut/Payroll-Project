package com.cg.payroll.dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.cg.payroll.beans.Employee;

public class PayrollDaoImpl implements IPayrollDAO
{
	@Autowired
	private SessionFactory sessionFactory;

	public int insertEmployee(Employee employee)  throws SQLException
	{
		sessionFactory.getCurrentSession().saveOrUpdate(employee);
		
		return 0;
	}

	public boolean updateEmployee(Employee employee)  throws SQLException {
		sessionFactory.getCurrentSession().update(employee);
		return false;
	}

	public boolean deleteEmployee(Employee employee)  throws SQLException {
		sessionFactory.getCurrentSession().delete(employee);
		return false;
	}

	public Employee getEmployee(int employeeId)  throws SQLException {
		
		return (Employee) sessionFactory.getCurrentSession().get(Employee.class, employeeId);
	}

	public List<Employee> getAllEmployee()   throws SQLException{
		return (List<Employee>) sessionFactory.getCurrentSession().createCriteria(Employee.class).list();
		
	}

}
